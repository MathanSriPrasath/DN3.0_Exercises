package EmployeeManagementSystem;

import java.util.ArrayList;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    // Method to add an employee
    public boolean addEmployee(Employee employee) {
        if (size < capacity) {
            employees[size++] = employee;
            return true;
        }
        return false; // Array is full
    }

    // Method to search for an employee by ID
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null; // Employee not found
    }

    // Method to traverse the array of employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Method to delete an employee by ID
    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                // Shift remaining elements to the left
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null; // Decrement size and clear last element
                return true;
            }
        }
        return false; // Employee not found
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(10);

        Employee e1 = new Employee(1, "Alice", "Developer", 60000);
        Employee e2 = new Employee(2, "Bob", "Manager", 80000);
        Employee e3 = new Employee(3, "Charlie", "Analyst", 70000);

        system.addEmployee(e1);
        system.addEmployee(e2);
        system.addEmployee(e3);

        System.out.println("All Employees:");
        system.traverseEmployees();

        System.out.println("\nSearching for Employee with ID 2:");
        System.out.println(system.searchEmployee(2));

        System.out.println("\nDeleting Employee with ID 2:");
        system.deleteEmployee(2);
        system.traverseEmployees();
    }
}
