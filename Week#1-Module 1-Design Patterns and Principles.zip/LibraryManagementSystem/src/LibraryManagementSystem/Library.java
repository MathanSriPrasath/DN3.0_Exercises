package LibraryManagementSystem;

import java.util.List;

public class Library {

    // Linear search method
    public Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Return null if the book is not found
    }
}
